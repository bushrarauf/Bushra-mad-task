#include <iostream>
using namespace std;

class Ticket {
public:
    virtual void bookSeat() {
        cout << "Standard seat allocated" << endl;
    }
};

class BusinessTicket : public Ticket {
public:
    void bookSeat() {
        cout << "Business class seat booked with extra legroom" << endl;
    }
};

class EconomyTicket : public Ticket {
public:
    void bookSeat() {
        cout << "Economy class seat booked" << endl;
    }
};

int main() {
    Ticket* t;
    BusinessTicket b;
    EconomyTicket e;

    t = &b;
    t->bookSeat();

    t = &e;
    t->bookSeat();

    return 0;
}

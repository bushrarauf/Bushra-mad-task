#include <iostream>
using namespace std;

class MathOperations {
public:
    int subtract(int a, int b) {
        return a - b;
    }
    int subtract(int a, int b, int c) {
        return a - b - c;
    }
    double subtract(double a, double b) {
        return a - b;
    }
};

int main() {
    MathOperations m;
    cout << "Sub 2 ints: " << m.subtract(50, 20) << endl;
    cout << "Sub 3 ints: " << m.subtract(100, 30, 20) << endl;
    cout << "Sub double: " << m.subtract(15.5, 4.2) << endl;
    return 0;
}

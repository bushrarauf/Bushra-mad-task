#include <iostream>
using namespace std;

class Document {
public:
    virtual void printFormat() {
        cout << "Generic document layout" << endl;
    }
};

class PdfDoc : public Document {
public:
    void printFormat() {
        cout << "Printing PDF document with fixed page size" << endl;
    }
};

class WordDoc : public Document {
public:
    void printFormat() {
        cout << "Printing Word document with editable margins" << endl;
    }
};

int main() {
    Document* d;
    PdfDoc pdf;
    WordDoc word;

    d = &pdf;
    d->printFormat();

    d = &word;
    d->printFormat();

    return 0;
}

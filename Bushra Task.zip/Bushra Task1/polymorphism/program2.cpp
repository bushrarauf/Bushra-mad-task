#include <iostream>
using namespace std;

class Weight {
public:
    int kg;

    Weight() {
        kg = 0;
    }
    Weight(int k) {
        kg = k;
    }
    Weight operator+(Weight w) {
        Weight temp;
        temp.kg = kg + w.kg;
        return temp;
    }
    void printWeight() {
        cout << "Total Weight: " << kg << " kg" << endl;
    }
};

int main() {
    Weight w1(25);
    Weight w2(35);
    Weight w3 = w1 + w2;
    w3.printWeight();
    return 0;
}

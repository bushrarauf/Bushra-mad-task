#include <iostream>
#include <string>
using namespace std;

class HotelRoom {
private:
    int roomNumber;
    int pricePerNight;

public:
    void setRoom(int num, int price) {
        roomNumber = num;
        pricePerNight = price;
    }
    int getRoomNumber() {
        return roomNumber;
    }
    int getPrice() {
        return pricePerNight;
    }
    void showRoom() {
        cout << "Room Number: " << roomNumber << endl;
        cout << "Price per Night: " << pricePerNight << " PKR" << endl;
    }
};

int main() {
    HotelRoom hr;
    hr.setRoom(305, 6000);
    hr.showRoom();
    return 0;
}

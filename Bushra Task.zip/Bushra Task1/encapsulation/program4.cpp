#include <iostream>
#include <string>
using namespace std;

class Tablet {
private:
    string modelName;
    int batteryHealth;

public:
    void setDetails(string m, int b) {
        modelName = m;
        batteryHealth = b;
    }
    int getBattery() {
        return batteryHealth;
    }
    void showInfo() {
        cout << "Tablet Model: " << modelName << endl;
        cout << "Battery Health: " << batteryHealth << "%" << endl;
    }
};

int main() {
    Tablet t;
    t.setDetails("iPad Air", 92);
    t.showInfo();
    return 0;
}

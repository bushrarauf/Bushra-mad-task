#include <iostream>
#include <string>
using namespace std;

class Wallet {
private:
    int balance;

public:
    void setInitial(int b) {
        balance = b;
    }
    void spend(int amt) {
        if (amt <= balance) {
            balance = balance - amt;
            cout << "Spent: " << amt << endl;
        } else {
            cout << "Cannot spend, low balance" << endl;
        }
    }
    int getBalance() {
        return balance;
    }
};

int main() {
    Wallet w;
    w.setInitial(3000);
    w.spend(1200);
    cout << "Remaining: " << w.getBalance() << endl;
    return 0;
}

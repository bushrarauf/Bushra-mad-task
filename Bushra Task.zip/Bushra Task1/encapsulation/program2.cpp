#include <iostream>
#include <string>
using namespace std;

class UniversityStudent {
private:
    string registrationNumber;
    float cgpa;

public:
    void setRegNo(string reg) {
        registrationNumber = reg;
    }
    string getRegNo() {
        return registrationNumber;
    }
    void setCgpa(float c) {
        if (c >= 0.0 && c <= 4.0) {
            cgpa = c;
        } else {
            cgpa = 0.0;
        }
    }
    float getCgpa() {
        return cgpa;
    }
    void displayCard() {
        cout << "Reg No: " << registrationNumber << endl;
        cout << "CGPA: " << cgpa << endl;
    }
};

int main() {
    UniversityStudent us;
    us.setRegNo("2024-CS-89");
    us.setCgpa(3.65);
    us.displayCard();
    return 0;
}

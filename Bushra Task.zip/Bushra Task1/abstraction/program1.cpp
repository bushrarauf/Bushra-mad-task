#include <iostream>
using namespace std;

class PlanFee {
public:
    virtual void showBilling() = 0;
};

class MonthlyPlan : public PlanFee {
private:
    int rate;

public:
    MonthlyPlan(int r) {
        rate = r;
    }
    void showBilling() {
        cout << "Monthly Plan: " << rate << " PKR/month" << endl;
    }
};

class YearlyPlan : public PlanFee {
private:
    int annualRate;

public:
    YearlyPlan(int r) {
        annualRate = r;
    }
    void showBilling() {
        cout << "Yearly Plan: " << annualRate << " PKR/year" << endl;
    }
};

int main() {
    MonthlyPlan m(1200);
    YearlyPlan y(11000);
    m.showBilling();
    y.showBilling();
    return 0;
}

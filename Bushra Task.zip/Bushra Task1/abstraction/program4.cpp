#include <iostream>
using namespace std;

class MessageGateway {
public:
    virtual void dispatch() = 0;
};

class WhatsAppGateway : public MessageGateway {
public:
    void dispatch() {
        cout << "Dispatching chat message over WhatsApp" << endl;
    }
};

class SlackGateway : public MessageGateway {
public:
    void dispatch() {
        cout << "Dispatching notification to Slack channel" << endl;
    }
};

int main() {
    WhatsAppGateway wag;
    SlackGateway slg;
    wag.dispatch();
    slg.dispatch();
    return 0;
}

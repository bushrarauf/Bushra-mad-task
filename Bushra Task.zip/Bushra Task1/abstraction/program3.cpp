#include <iostream>
using namespace std;

class Engine {
public:
    virtual void ignite() = 0;
};

class PetrolEngine : public Engine {
public:
    void ignite() {
        cout << "Petrol engine sparked" << endl;
    }
};

class ElectricMotor : public Engine {
public:
    void ignite() {
        cout << "Electric battery power supplied to motor" << endl;
    }
};

int main() {
    PetrolEngine pe;
    ElectricMotor em;
    pe.ignite();
    em.ignite();
    return 0;
}

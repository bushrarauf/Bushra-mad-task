#include <iostream>
using namespace std;

class AuthSystem {
public:
    virtual void login() = 0;
};

class PasswordLogin : public AuthSystem {
public:
    void login() {
        cout << "Logging in using username and password" << endl;
    }
};

class FingerprintLogin : public AuthSystem {
public:
    void login() {
        cout << "Logging in using biometric fingerprint" << endl;
    }
};

int main() {
    PasswordLogin pl;
    FingerprintLogin fl;
    pl.login();
    fl.login();
    return 0;
}

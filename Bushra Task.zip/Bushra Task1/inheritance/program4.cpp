#include <iostream>
using namespace std;

class WrittenTest {
public:
    int written;

    void setWritten(int w) {
        written = w;
    }
};

class Interview {
public:
    int interview;

    void setInterview(int i) {
        interview = i;
    }
};

class SelectionStatus : public WrittenTest, public Interview {
public:
    void showStatus() {
        int total = written + interview;
        cout << "Written: " << written << endl;
        cout << "Interview: " << interview << endl;
        cout << "Score: " << total << endl;
    }
};

int main() {
    SelectionStatus ss;
    ss.setWritten(60);
    ss.setInterview(30);
    ss.showStatus();
    return 0;
}

#include <iostream>
#include <string>
using namespace std;

class Institution {
public:
    string instName;

    void setInstitution(string n) {
        instName = n;
    }
};

class College : public Institution {
public:
    string city;

    void setCollege(string n, string c) {
        setInstitution(n);
        city = c;
    }
    void display() {
        cout << "College: " << instName << endl;
        cout << "City: " << city << endl;
    }
};

int main() {
    College col;
    col.setCollege("Punjab College", "Lahore");
    col.display();
    return 0;
}

#include <iostream>
#include <string>
using namespace std;

class Beverage {
public:
    void serve() {
        cout << "Serving hot beverage" << endl;
    }
};

class Tea : public Beverage {
public:
    void prepareTea() {
        cout << "Adding tea leaves and milk" << endl;
    }
};

class Coffee : public Beverage {
public:
    void brewCoffee() {
        cout << "Brewing espresso beans" << endl;
    }
};

int main() {
    Tea t;
    t.serve();
    t.prepareTea();

    Coffee c;
    c.serve();
    c.brewCoffee();
    return 0;
}

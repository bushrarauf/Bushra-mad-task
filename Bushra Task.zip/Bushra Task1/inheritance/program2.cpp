#include <iostream>
#include <string>
using namespace std;

class Gadget {
public:
    int warrantyMonths;

    void setWarranty(int w) {
        warrantyMonths = w;
    }
};

class Computer : public Gadget {
public:
    string processor;

    void setComputer(int w, string p) {
        setWarranty(w);
        processor = p;
    }
};

class DesktopPC : public Computer {
public:
    int powerSupplyWatts;

    void setDesktop(int w, string p, int ps) {
        setComputer(w, p);
        powerSupplyWatts = ps;
    }
    void showPC() {
        cout << "Warranty: " << warrantyMonths << " months" << endl;
        cout << "Processor: " << processor << endl;
        cout << "PSU: " << powerSupplyWatts << "W" << endl;
    }
};

int main() {
    DesktopPC pc;
    pc.setDesktop(24, "Intel i7", 650);
    pc.showPC();
    return 0;
}
